# Author: Jessica Trujillo
# Date: April 15, 2022
# V.1.0

class IndicatorInterface:
    def count(self, p) -> int:
        return 0
    def getType(self) -> str:
        return "unkown"