# Author: Jessica Trujillo
# Date: April 15, 2022
# V.1.0

class JsonPost:
    id = 0 
    userId = ""
    parentId = 0

    contents = ""
    postItems = []
    score = 0
    author = ""

    posWords = 0
    negWords = 0