# Author: Jessica Trujillo
# Date: April 15, 2022
# V.1.0

import os

currentLocation = os.path.realpath(os.path.join(os.getcwd(), os.path.dirname(__file__)))

